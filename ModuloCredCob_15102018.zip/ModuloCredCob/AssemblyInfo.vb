Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("M�dulo de Cr�dito y Cobranza")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("CyC�")> 
<Assembly: AssemblyCopyright("Autor: Rodrigo D�az Concha")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("1CFEDF62-5059-4FF1-879A-EEDBA09C867E")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("2.0.0.0")>      '1.0.2.33 nva

'Notas de la vers��n 1.0.1.84
'****************************
'Busqueda de documentos por vale de cr�dito, pedidoreferencia en el cierre de cobranza

'Notas de la versi�n 1.0.1.70
'******************************
'Cambi� la exportaci�n tm3 para no usar excel
'Nueva versi�n de arqueo
'Correcci�nes de pago referenciado
'Carga de cat�logo de ejecutivos en memoria (dataset)


